% *********************PROGRAM TO DRAW PARAMETRIC LINE **********
% INPUT ARGUMENTS : START AND END PARAMETERS
% OUTPUT : GRAPH OF LINE
% *************************************************************************


clc;
clear;
close all;
format short;
hold on;
grid on;

axis([-500,500,-500,500]);

%input variables

x1 = 80;
y1 = 80;

x2 = 250;
y2 = 100;

x3 = 150;
y3 = 200;

%plot of line p1p2
for u=0:0.1:1
    x = x1 + u*(x2-x1);
    y = y1 + u*(y2-y1);
    plot(x,y,'k+');hold on;
end

plot(x3,y3,'r*');hold on;     %plot of p3

L = sqrt(((x2-x1)*(x2-x1))+((y2-y1)*(y2-y1)));   %length of line p1p2
n1x = (x2-x1)/L;   %x dir of unit vector of p1p2 line
n1y = (y2-y1)/L;

n2y = n1x;   %perpendicular directions
n2x = -n1y;

D = (((x3-x1)*n1y) - ((y3-y1)*n1x));    %cross product gives perpendicular vector

x4 = x3 + D*n2x;       %p4 is component of p3 in n2 direction
y4 = y3 + D*n2y;

%plot of p3p4

for u=0:0.1:1
    x = x3 + u*(x4-x3);
    y = y3 + u*(y4-y3);
    plot(x,y,'b+');hold on;
end