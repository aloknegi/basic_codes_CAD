% *********************PROGRAM TO DRAW PARAMETRIC ELLIPSE **********
% INPUT ARGUMENTS : START AND END PARAMETERS
% OUTPUT : ELLIPSE
% *************************************************************************

clc;
close all;
hold on;
grid on;
axis([0,100,0,100]);
a =20; b = 10;
x0 = 50;
y0 = 50;
plot(x0,y0,'b*');
c = cos(pi/180);
s = sin(pi/180);
x = a;
y = 0;

for i = 1:90
    x1 = ((x*c) - ((a/b)*y*s));
    y1 = ((y*c) + ((b/a)*x*s));
    x = x1;
    y = y1;
    plot(x+x0,y+y0,'r*');
    plot(-x+x0,y+y0,'b*');
    plot(-x+x0,-y+y0,'k*');
    plot(x+x0,-y+y0,'c*');
end
