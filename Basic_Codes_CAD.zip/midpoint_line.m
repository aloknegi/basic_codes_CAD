% ********************MIDPOINT LINE ALGO*****************

clc;
clear all;
close all;
format short;
x0=30;
y0=40;
x=x0;
y=y0;
x1=200;
y1=100;
axis=([-100,200,-100,200]);
a=y1-y0;
b=-(x1-x0);
d=a+(b/2);
while (x<=x1 && y<=y1)
    if (d<0)
        x=x+1;
        plot(x,y,'r*');hold on;
        d=d+a;
    else %(d>=0)
        x=x+1;
        y=y+1;
        plot(x,y,'k+');hold on;
        d=d+a+b;
    end
end