% % *********************INSCRIBE ELLIPSE CIRCLE INSIDE RECTANGLE******************
clc;
close all;
hold on;
grid on;

%given coordinates of rectangle
x1 = 50;
y1 = 50;

x2 = 150;
y2 = 50;

x3 = 150;
y3 = 100;

x4 = 50;
y4 = 100;

%plot of p1p2 line
for u=0:0.01:1
    x = x1 + u*(x2-x1);
    y = y1 + u*(y2-y1);
    plot(x,y,'b*');hold on;
end

%plot of p2p3 line
for u=0:0.01:1
    x = x2 + u*(x3-x2);
    y = y2 + u*(y3-y2);
    plot(x,y,'r*');hold on;
end

%plot of p3p4 line
for u=0  :0.01:1
    x = x3 + u*(x4-x3);
    y = y3 + u*(y4-y3);
    plot(x,y,'b*');hold on;
end

%plot of p4p1 line
for u=0:0.01:1
    x = x1 + u*(x4-x1);
    y = y1 + u*(y4-y1);
    plot(x,y,'r*');hold on;
end

%calculation of centre
xc = (x1 + x3)/2;
yc = (y1 + y3)/2;

%plot of centre point
plot(xc,yc,'r*');

%calculation of point  a and b
m = x3 - xc;
n = y3 - yc;

r = 2;   %ratio of major to minor axis a/b

t = (((m*m)/(r*r)) + (n*n)); %equation used to calculate 'b'

b = sqrt(t);
a = b*r;

%display of major axis and minor axis
disp(a);
disp(b);

%ellipse plot
c = cos(pi/180);
s = sin(pi/180);
x = a;
y = 0;
x0 = xc;
y0 = yc;
plot(x0,y0,'b+');

for i = 1:90
    x1 = ((x*c) - ((a/b)*y*s));
    y1 = ((y*c) + ((b/a)*x*s));
    x = x1;
    y = y1;
    plot(x+x0,y+y0,'r*');
    plot(-x+x0,y+y0,'b*');
    plot(-x+x0,-y+y0,'k*');
    plot(x+x0,-y+y0,'c*');
end