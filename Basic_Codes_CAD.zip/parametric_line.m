% *********************PROGRAM TO DRAW PARAMETRIC LINE **********
% INPUT ARGUMENTS : START AND END PARAMETERS
% OUTPUT : LINE
% *************************************************************************


clc;
clear;
close all;
format short;
hold on;

axis([-100,100,-100,100]);


%input parameters
x1 = 40;
y1 = 30;
x2 = 100;
y2 = 80;

% for loop for plotting of line using parametric equation i.e.
% p = p1 +u*(p2-p1)
% where p1 and p2 is starting and ending point of line
% u is a parameter

for u=0:0.01:1
    x = x1 + u*(x2-x1);
    y = y1 + u*(y2-y1);
    plot(x,y,'r+');
end
