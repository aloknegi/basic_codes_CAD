% ********************PLOT PARALLEL LINE PARAMETRIC*****************

clc;
close all;
clear all;
grid on;
hold on;

axis([0,200,0,200]);

%given points

x1 = 50;
y1 = 120;

x2 = 120;
y2 = 200;

x3 = 60;
y3 = 70;

x4 = 200;
y4= 90;

r = 50;  %radius of circle

%plot of p1p2
for u=0:0.01:1
    x = x1 + u*(x2-x1);
    y = y1 + u*(y2-y1);
    plot(x,y,'b*');hold on;
end

%plot of p3p4
for u=0:0.01:1
    x = x3 + u*(x4-x3);
    y = y3 + u*(y4-y3);
    plot(x,y,'b*');hold on;
end

L1 = sqrt((x2-x1)^2 + (y2-y1)^2);  %unit vector in p1p2 dir
n1x = (x2-x1)/L1;
n1y = (y2-y1)/L1;
n1z = 0;

L2 = sqrt((x4-x3)^2 + (y4-y3)^2);  %unit vector in p3p4 dir
n2x = (x4-x3)/L2;
n2y = (y4-y3)/L2;
n2z = 0;

n3x = 0;  %perpendicular vector n1xn2
n3y = 0;
n3z =-1;

n4x = ((n3y*n1z) - (n1y*n3z));  %cross product of n3 and n1
n4y = -((n3x*n1z) - (n1x*n3z));
n4z = ((n3x*n1y) - (n1x*n3y));

n5x = ((n2y*n3z) - (n3y*n2z)); %cross product of n2 and n3
n5y = -((n2x*n3z) - (n3x*n2z));
n5z = ((n2x*n3y) - (n3x*n2y));

s = (((x3-x1)*n5x) + ((y3-y1)*n5y)) ; %(p3-p1)*n5

t = (r*(1-((n4x*n5x) + (n4y*n5y) + (n4z*n5z))));  %n4*n5*r

v = ((x2-x1)*n5x) + ((y2-y1)*n5y)  ; %(p2-p1)*n5

u = (s+t)/v ;

xc = x1 + (u*(x2-x1))+ (n4x*r);

yc = y1 + (u*(y2-y1))+ (n4y*r);

x = 0;
y = r;

hold on;

%mid point circle
d=(5/4)-r;
while (y>=x)
    if (d<0)
        d=d+(2*x)+3;
        x=x+1;
        plot(x+xc,y+yc,'r*');hold on;
        
    else
        x=x+1;
        y=y-1;
        d=d+(2*x)-(2*y)+5;
        plot(x+xc,y+yc,'r*');hold on;
        
    end
    plot(y+xc,x+yc,'r*');hold on;
    plot(y+xc,-x+yc,'r*');hold on;
    plot(+x+xc,-y+yc,'r*');hold on;
    plot(-x+xc,-y+yc,'r*');hold on;
    plot(-y+xc,-x+yc,'r*');hold on;
    plot(-y+xc,x+yc,'r*');hold on;
    plot(-x+xc,y+yc,'r*');hold on;
end
