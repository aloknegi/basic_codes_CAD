%initial settings
clc;
clear;
close all;
format short;
axis([-50 100 -50 100]);

%variable decleration
x=25;   %centre
y=30;
r=10;   %radius

%algo for DDA_CIRCLE
for th=0:45    %variation of theta wrt r
    th1=th*(3.14/180);   %theta in radians
    a=r*cos(th1);
    b=r*sin(th1);
    plot(a+x,b+y,'r');hold on;   %symmetry 8 ways
    plot(b+x,a+y,'r');hold on;
    plot(-b+x,a+y,'r');hold on;
    plot(-a+x,b+y,'r');hold on;
    plot(-a+x,-b+y,'r');hold on;
    plot(-b+x,-a+y,'r');hold on;
    plot(b+x,-a+y,'r');hold on;
    plot(a+x,-b+y,'r');hold on;
end
