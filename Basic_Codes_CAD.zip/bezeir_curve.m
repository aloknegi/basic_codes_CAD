% *********************PROGRAM FOR BEZEIR CURVE ******************
% INPUT ARGUMENTS : COORDINATES AND TANGENT VECTORS
% OUTPUT : PLOT OF BEZEIR CURVE
% *************************************************************************

clc;
clear;
close all;
format short;
hold on;
grid on;
%Program for Bezeir Curve
n = 8;                             %number of control points
d = n-1;                           %degree of  the curve
X = [200,50,50,50,50,100,150,200];     %x Coordinates of control polygon
Y = [100,150,150,150,150,200,150,100]; %y coordiantes of control polygon
line(X,Y);                         %plotting the control polygon
for u = 0:0.01:1                   %for loop for parameter u = 0 to u = 1
    x=0; y=0;                      %starting point
    for i=0:1:d                    %for loop for calculating all 'B' functions 
        c=nchoosek(d,i);           %dCi ,'i' combinations from 'd' items
        B=c*((u^i)*(1-u)^(d-i));   %bernstein function
        x=x+B*X(i+1);              %x coordiante of bezeir func
        y=y+B*Y(i+1);              %y coordinate of bezeir func
    end;                           %ending of the for loop
plot(x,y,'*r');                    %plotting of the bezeir curve
end