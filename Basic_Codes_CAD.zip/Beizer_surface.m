%*********************PROGRAM FOR BEZIER SURFACE **************************
% INPUT ARGUMENTS : TWO CURVES
% OUTPUT : PLOT OF PLANE SURFACE
% *************************************************************************


clc;
close all;
format short;
%INPUT ARGUMENTS
p= [ 60 100 170 220;
    60 100 150 250;
    40 100 180 220];
q = [ 60 80 30 30;
    100 120 150 200;
    250 280 280 300];
r = [10 10 10 10;
    20 20 20 20;
    30 30 30 30];
n = 4;  % n is the degree  in u direction
m = 3;  % m is the degree  in v direction
i=1;j=1;
for u=0:.1:1
    for v=0:.1:1
        x=0;y=0;z=0;
        for i=0:1:n-1
            for j=0:1:m-1
                cu=nchoosek(n-1,i);
                Bu=cu*(u^i)*((1-u)^((n-1)-i));
                cv=nchoosek(m-1,j);
                Bv=cv*(v^j)*((1-v)^((m-1)-j));
                x= x+ p(j+1,i+1)*Bu*Bv;
                y= y+ q(j+1,i+1)*Bu*Bv;
                z= z+ r(j+1,i+1)*Bu*Bv;
            end
        end
        plot3(x,y,z,'*b'); grid on;hold on;rotate3d on;
        figure(2)
        dt = delaunayn([x',y',z'])
        tetramesh(dt,[x',y',z'],'FaceAlpha',0.1);
    end
end