% *********************PROGRAM FOR B-SPLINE CURVE**************************
% INPUT ARGUMENTS : COORDINATES AND DEGREE
% OUTPUT : PLOT OF B-SPLINE CURVE
% *************************************************************************

clc;
close all;
format short;
hold on;
grid on;
%Program for B-Spline Curve
n = 4;                       %control points = n+1
d = n+1;                     %variable representing control points
k = 3;                       %degree = k-1
X = [50,80,150,180,220];     %x Coordinates of control polygon
Y = [50,150,160,100,150];    %y coordiantes of control polygon
line(X,Y);                   %plotting the control polygon
umax=n-k+2;                  %maximum value of 'u'

%Loop for calculating KNOT Vectors
for j=0:1:(n+k)
    if j<k
        t = 0;
    elseif (k>=j) && (j<=n)
        t = j-k+1;
    elseif j>n
        t = (n-k)+2;
    end
    disp(t);
end
for u = 0:0.01:3            %for loop for parameter u = 0 to u = 1
    x = 0;y =0;                 %starting point
    for i =0:1:d                %for loop for calculating all 'N' functions
        N=blend_1(i,u,t,k);     %calling N function
        x = x+N*X(i+1);         %x coordiante of b-spline func
        y = y+N*Y(i+1);         %y coordiante of b-spline func
    end
    plot(x,y,'r*');             %plotting of the b-spline curve
end  