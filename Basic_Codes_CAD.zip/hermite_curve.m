% *********************PROGRAM FOR HERMITE CURVE ******************
% INPUT ARGUMENTS : COORDINATES AND TANGENT VECTORS
% OUTPUT : PLOT OF HERMITE CURVE
% *************************************************************************


clc;
clear;
close all;
format short;
hold on;
grid on;

%INPUT ARGUMENTS
%start and end points
x0 = 4;   
y0 = 4;
x1 = 4;
y1 = 24;

%unit vector for defining tangent vector
t0x = 0.8320;  
t0y = 0.5547;
k0 = [10 20 30 40];    %weight vector
t1x = 0.8320;
t1y = -0.5547;
k1 = [10 20 30 40];    %weight vector


%checking that is tangent vector a unit vector
vec = sqrt((t0x^2)+(t0y^2));
disp(vec);

%tangent vectors
x01 = k0*t0x;  %initial tangent vector with weights
y01 = k0*t0y;

x11 = k1*t1x;  %final tangent vector with weights
y11 = k1*t1y;

%plotting of hermite curve

for u=0:0.005:1
    f1 = (2*u*u*u)-(3*u*u)+1;
    f2 = (-2*u*u*u)+(3*u*u);
    f3 = (u*u*u)-(2*u*u)+u;
    f4 = (u*u*u)-(u*u);
    
    x = (f1*x0)+(f2*x1)+(f3*x01)+(f4*x11);
    y = (f1*y0)+(f2*y1)+(f3*y01)+(f4*y11);
    
    plot(x,y,'*b');hold on;
end