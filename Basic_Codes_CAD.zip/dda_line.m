
% DDA LINE ALGORITHM
clc;
clear all
format short
axis([0,70,0,70]);
%variable decleration
x1=10;
x2=60;
y1=50;
y2=60;

%slope
m=((y2-y1)/(x2-x1));

%iterating the point x and y on the line
x=x1;
y=y1;

%algo for DDA_LINE
while (x<=x2 && y<=y2)
    if ((x2-x1)>(y2-y1))
        x=x+1;
        y=y+m;
        plot(x,y,'r+'); hold on;
    else
        y=y+1;
        x=x+(1/m);
        plot(x,y,'k+'); hold on;
    end
end
