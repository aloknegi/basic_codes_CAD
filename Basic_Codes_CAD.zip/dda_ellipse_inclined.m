%settings
clc;
clear all;
close all;
format short;
axis([-150,150,-150,150]); 

%variable decleration
x=25; %centre
y=30;
plot(x,y,'r*');hold on;
r1=50;   %major axis
r2=25;    %minor axis
alpha = pi/4;
%algo for DDA_ELLIPSE
for th=0:1:180
    th1=th*(3.14/180);
    a=((r1*(cos(th1)*cos(alpha)))-(r2*sin(th1)*sin(alpha)));
    b=((r1*(cos(th1)*sin(alpha)))+(r2*sin(th1)*cos(alpha)));
    plot(a+x,b+y,'r*');hold on;
    plot(-a+x,-b+y,'b*');
end