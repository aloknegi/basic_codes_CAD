clc;
close all;
hold on;
grid on;

axis([0 200 0 150]);
x1 = 50;
y1 = 50;

x2 = 150;
y2 = 50;

x3 = 150;
y3 = 100;

x4 = 50;
y4 = 100;

%plot of p1p2
for u=0:0.01:1
    x = x1 + u*(x2-x1);
    y = y1 + u*(y2-y1);
    plot(x,y,'b*');hold on;
end

%plot of p2p3
for u=0:0.01:1
    x = x2 + u*(x3-x2);
    y = y2 + u*(y3-y2);
    plot(x,y,'r*');hold on;
end

%plot of p3p4
for u=0  :0.01:1
    x = x3 + u*(x4-x3);
    y = y3 + u*(y4-y3);
    plot(x,y,'b*');hold on;
end

%plot of p4p1
for u=0:0.01:1
    x = x1 + u*(x4-x1);
    y = y1 + u*(y4-y1);
    plot(x,y,'r*');hold on;
end

xc = (x1 + x3)/2;
yc = (y1 + y3)/2;
plot(xc,yc,'r*');

x5 = (x2 + x3)/2;
y5 = (y2 + y3)/2;

a = sqrt((x5 - xc)^2 + (y5 - yc)^2);

x6 = (x3 + x4)/2;
y6 = (y3 + y4)/2;

b = sqrt((x6 - xc)^2 + (y6 - yc)^2);

c = cos(pi/180);
s = sin(pi/180);
x = a;
y = 0;
x0 = xc;
y0 = yc;
plot(x0,y0,'b+');

%ellipse plot
for i = 1:90
    x1 = ((x*c) - ((a/b)*y*s));
    y1 = ((y*c) + ((b/a)*x*s));
    x = x1;
    y = y1;
    plot(x+x0,y+y0,'r*');
    plot(-x+x0,y+y0,'b*');
    plot(-x+x0,-y+y0,'k*');
    plot(x+x0,-y+y0,'c*');
end
