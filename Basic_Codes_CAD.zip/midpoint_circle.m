% ********************MIDPOINT CIRCLE ALGO*****************

clc;
clear;
format short;
close all;
axis=([0,500,0,500]);
x0 = 0;
y0 = 0;
plot(x0,y0,'r*');hold on;
r=50;
x=0;
y=r;
hold on;
plot(x,y,'r*');
d=(5/4)-r;
while (y>=x)
    if (d<0)
        d=d+(2*x)+3;
        x=x+1;
        plot(x,y,'r+');hold on;
    else
        x=x+1;
        y=y-1;
        d=d+(2*x)-(2*y)+5;
        plot(x,y,'r+');hold on;
    end
    plot(y,x,'r+');hold on;
    plot(y,-x,'r+');hold on;
    plot(x,-y,'r+');hold on;
    plot(-x,-y,'r+');hold on;
    plot(-y,-x,'r+');hold on;
    plot(-y,x,'r+');hold on;
    plot(-x,y,'r+');hold on;
end
