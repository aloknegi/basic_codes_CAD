%*********************PROGRAM FOR OPEN B-SPLINE CURVE ******************
% INPUT ARGUMENTS : COORDINATES AND DEGREE
% OUTPUT : PLOT OF B-SPLINE CURVE
% *************************************************************************

clc;
close all;
n=5;                        %n=N-1 N is the no. of control points
k=3;                        %degree 3 for quadratic
x=[50,80,150,180,220];  %points x cordinates
y=[50,150,160,100,150]; %points y coordinates
line(x,y);hold on;          %line through points
%for knot vectors
j=n+k;                              %knot vector limit
for i=1:1:j                         %starting from 1 because matlab not consider 0
    l=k+1;                          %increment in k because t0 value is shifting to t1
    if  i<l
        t(i)=0;
    elseif i>=l && i<=n+1
        t(i)=i-k;               % i-k instead of i-k+1
    else
        t(i)=n-k+1;              % n-k+1 instead of n-k+2
    end;
end;
disp(t);       % display knot vectors
% for Bspline equation
um=n-k+1;      % u maximum value n-k+1 intead of n-k+2 (k vale change to k+1)
for u=0:0.01:um
    x1=0; y1=0;
    for i=1:n
        b= B_Spline(t,k,u,i);  % Bspline function
        x1=x1+(b*x(i));
        y1=y1+(b*y(i));
    end;
    plot(x1,y1,'*','LineWidth',1);hold on;axis([0,250,0,180]);
end