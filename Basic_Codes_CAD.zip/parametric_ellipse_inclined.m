% *********************PROGRAM TO DRAW PARAMETRIC ELLIPSE INCLINED **********
% INPUT ARGUMENTS : START AND END PARAMETERS
% OUTPUT : ELLIPSE
% *************************************************************************

clc;
hold on;
axis([-100,100,-100,100]);
r1 =80; r2 = 40;
alpha = pi/4;
for u = 0:1:180
    th1 = u*pi/180;
    x=(r1*cos(th1)*cos(alpha))-(r2*sin(th1)*sin(alpha));
    y=(r1*cos(th1)*sin(alpha))+(r2*sin(th1)*cos(alpha));
    plot(x,y,'r*');
    plot(-x,-y,'r*');
end