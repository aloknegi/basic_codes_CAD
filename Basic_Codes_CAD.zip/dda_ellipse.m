%settings
clc;
clear all;
format short;
axis([0,100,0,100])

%variable decleration
x=25; %centre
y=30;
plot(x,y,'r*');hold on;
r1=20;   %major axis
r2=10;    %minor axis

%algo for DDA_ELLIPSE  
for th=0:1:90 %incriment of one degree
    th1=th*(3.14/180);
a=r1*cos(th1);
b=r2*sin(th1);
plot(a+x,b+y,'r*');hold on; %4 way symmetry
plot(-a+x,b+y,'k*');hold on;
plot(-a+x,-b+y,'c*');hold on;
plot(a+x,-b+y,'b*');hold on;
end