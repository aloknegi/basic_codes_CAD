% *********************PROGRAM TO DRAW PARAMETRIC LINE **********
% INPUT ARGUMENTS : START AND END PARAMETERS
% OUTPUT : GRAPH OF LINE
%
% CREATED BY : BALTEJ SINGH ON JAN 28,2015
% LAST MODIFIED ON : JAN 28,2015
% LINE 10 : CHANGE 1
% LINE 20 : CHANGE 2
% *************************************************************************


% SETTINGS
clc;
clear all;
close all;
format short;
hold on;
grid on;

axis([-500,500,-500,500]);

%input variables

x1 = 80;
y1 = 10;

x2 = 300;
y2 = 50;

x3 = 50;
y3 = 50;

x4 = 200;
y4 = 150;


%plot of p3p4
for u=0:0.01:1
    x = x3 + u*(x4-x3);
    y = y3 + u*(y4-y3);
    plot(x,y,'r+');hold on;
end

%locating points p1 and p2
plot(x1,y1,'k*');hold on;
plot(x2,y2,'b*');hold on;


%calculating unit vector in dir of p3p4 line
D = sqrt(((x4-x3)*(x4-x3))+((y4-y3)*(y4-y3)));  %magnitude of p3p4
n1x = (x4-x3)/D;  %x component of unit vector in p3p4 dir
n1y= (y4-y3)/D;

L = (x2-x1)*n1x + (y2-y1)*n1y;   %length of line p1p5

x5 = x1 + L*n1x;    %coods of point p5
y5 = y1 + L*n1y;


%plotting p1p5 line
for u=0:0.01:1
    x = x1 + u*(x5-x1);
    y = y1 + u*(y5-y1);
    plot(x,y,'b+'); hold on;
end

%plotting p5p2 line
for u=0:0.01:1
    x = x2 + u*(x5-x2);
    y = y2 + u*(y5-y2);
    plot(x,y,'g+'); hold on;
end