% *********************PROGRAM TO DRAW PARAMETRIC CIRCLE**********
% INPUT ARGUMENTS : START AND END PARAMETERS
% OUTPUT : CIRCLE
% *************************************************************************

clc;
hold on;
grid on;
axis([-100,100,-100,100]);
r =30;
x0 = 10;
y0 = 10;
plot(x0,y0,'b*'); %centre point
c = cos(pi/180);
s = sin(pi/180);
x = r;
y = 0;
for i = 1:45 
    x1 = x*c - y*s;
    y1 = x*s + y*c;
    x = x1;
    y = y1;
    plot(x+x0,y+y0,'r+');hold on;
    plot(y+x0,x+y0,'r+');hold on;
    plot(y+x0,-x+y0,'r+');hold on;
    plot(x+x0,-y+y0,'r+');hold on;
    plot(-x+x0,-y+y0,'r+');hold on;
    plot(-y+x0,-x+y0,'r+');hold on;
    plot(-y+x0,x+y0,'r+');hold on;
    plot(-x+x0,y+y0,'r+');hold on;
end